package com.example.cetvrtopredavanje

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase

@Database(entities = arrayOf(Note::class), version =  1)
abstract class NotesDatabase: RoomDatabase() {

    abstract  fun noteDao(): NoteDao

}