package com.example.cetvrtopredavanje

import android.arch.persistence.room.Room
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var notesAdapter: NotesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = Room.databaseBuilder(
            applicationContext,
            NotesDatabase::class.java,"note_database"
        ).build()

        listOfNotesRecycleView.layoutManager = LinearLayoutManager(this)
        notesAdapter = NotesAdapter()
        listOfNotesRecycleView.adapter = notesAdapter

        Thread(
            Runnable {
                for (note in db.noteDao().getAllNotes()){
                    NotesList.notesList.add(note)
                }
            }
        ).start()

        floatingActionButton3.setOnClickListener{
            val startNoteDetailsActivity = Intent(this, NoteDetailsActivity::class.java)
            startNoteDetailsActivity.putExtra("novo",1)
            startActivity(startNoteDetailsActivity)
        }

    }

    override fun onResume() {
        super.onResume()
        notesAdapter.notifyDataSetChanged()
    }
}
