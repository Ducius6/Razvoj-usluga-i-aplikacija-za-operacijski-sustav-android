package com.example.cetvrtopredavanje

import android.arch.persistence.room.Room
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_note_details.*
import java.text.SimpleDateFormat
import java.util.*


class NoteDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_details)

        val db = Room.databaseBuilder(
            applicationContext,
            NotesDatabase::class.java,"note_database"
        ).build()

        if(intent.getIntExtra("novo", 0).equals(0)){
            val position = intent.getIntExtra("pozicija", -1)
            val note = NotesList.notesList.get(position)
            notesTitleText.setText(note.noteTitle)
            noteDescription.setText(note.noteDescription)
        }

        button2.setOnClickListener {
            val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
            val currentDate = sdf.format((Date()))
            if(intent.getIntExtra("new",1).equals(1)){
                var note = Note(uid = notesTitleText.text.hashCode(), noteTitle = notesTitleText.text.toString(), noteDate = currentDate, noteDescription = noteDescription.text.toString())
                Thread(
                    Runnable {
                        db.noteDao().insertAll(note)
                        NotesList.notesList.add(note)
                    }).start()
                finish()
            }
            else{
                val position = intent.getIntExtra("position", -1)
                val note = NotesList.notesList.get(position)
                Thread(
                    Runnable {
                        note.noteTitle = notesTitleText.text.toString()
                        note.noteDescription = noteDescription.text.toString()
                        note.noteDate = currentDate
                        db.noteDao().updateNote(note.noteDate, note.noteTitle, note.noteDescription, note.uid)
                    }).start()
                finish()
            }
        }

    }
}
