package com.example.cetvrtopredavanje

class Note {

    var noteDescription: String? = null
    var noteTitle: String? = null
    var noteDate:String? = null



}