package com.example.stoperica

import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    var worker: DoInBackground? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startButton.setOnClickListener {
            worker = DoInBackground()
            worker?.execute()
            worker?.running = true
            resetButton.isEnabled = false
            startButton.visibility = View.GONE
            pauseButton.visibility = View.VISIBLE
            resetButton.visibility = View.VISIBLE
            pauseButton.setText("Pause")
        }

        pauseButton.setOnClickListener {
            if(worker?.running == true){
                worker?.running = false
                startButton.visibility = View.GONE
                pauseButton.setText("Start")
                resetButton.isEnabled = true
                pauseButton.visibility = View.VISIBLE
                resetButton.visibility = View.VISIBLE
            }
            else{
                worker = DoInBackground()
                worker?.execute()
                worker?.running = true
                startButton.visibility = View.GONE
                resetButton.isEnabled = false
                pauseButton.setText("Pause")
                pauseButton.visibility = View.VISIBLE
                resetButton.visibility = View.VISIBLE
            }
        }


        resetButton.setOnClickListener {

            pauseButton.visibility = View.GONE
            pauseButton.setText("Pause")
            stopericaVrijeme.setText("00:00:00")
            worker?.minute = 0
            worker?.sekunde = 0
            worker?.milisekunde = 0
            resetButton.visibility = View.GONE
            startButton.visibility = View.VISIBLE
            resetButton.isEnabled = false
        }
    }

    inner class DoInBackground:AsyncTask<Int,Long,Unit>(){

        var running:Boolean = false
        var minute :Long = 0
        var sekunde: Long = 0
        var milisekunde:Long = 0


        override fun onProgressUpdate(vararg values: Long?) {
            super.onProgressUpdate(*values)

            if(running){
                milisekunde += values.first()!!.toInt()
                if(milisekunde>=1000){
                    sekunde += 1
                    milisekunde -= 1000
                }
                if (sekunde>=60){
                    minute += 1
                    sekunde -= 60
                }
                stopericaVrijeme.setText(vrijemeToString(minute, sekunde,milisekunde))
            }
        }


        override fun doInBackground(vararg params: Int?) {

            var vrijeme = stopericaVrijeme.text.split(":")
            minute = vrijeme[0].toLong()
            sekunde = vrijeme[1].toLong()
            milisekunde = vrijeme[2].toLong()
            val pom: Long = 30

            while(running){
                Thread.sleep(pom)
                this.publishProgress(pom)
            }
        }


        fun vrijemeToString(minute:Long, sekunde:Long, milisekunde:Long): String {
            var str: String = ""

            if(minute>=10){
                str += minute.toInt().toString() + ":"
            }
            else{
                str+= "0" + minute.toInt().toString() + ":"
            }

            if (sekunde>=10){
                str+= sekunde.toInt().toString()+":"
            }
            else{
                str+= "0"+ sekunde.toInt().toString()+":"
            }

            if(milisekunde<10){
                str+= "0" +  milisekunde.toInt().toString()
            }
            else if (milisekunde<100){
                str+= milisekunde.toInt().toString()
            }
            else{
                str+= (milisekunde/10).toInt().toString()
            }

            return str

        }
    }
}
