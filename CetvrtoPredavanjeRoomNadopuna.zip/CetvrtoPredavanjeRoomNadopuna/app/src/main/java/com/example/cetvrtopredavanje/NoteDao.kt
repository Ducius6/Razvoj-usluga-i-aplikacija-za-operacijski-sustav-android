package com.example.cetvrtopredavanje

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query

@Dao
interface NoteDao {

    @Insert
    fun insertAll(vararg noteList:Note)

    @Query("SELECT * FROM NOTE")
    fun getAllNotes(): List<Note>

    @Query("UPDATE note SET noteDate = :noteDate, noteTitle = :noteTitle, noteDescription = :noteDescription  WHERE uid = :noteId")
    fun updateNote(noteDate: String?, noteTitle: String?, noteDescription: String?, noteId: Int?)

    @Query("DELETE FROM NOTE WHERE uid = :noteId")
    fun deleteNote(noteId: Int)

}