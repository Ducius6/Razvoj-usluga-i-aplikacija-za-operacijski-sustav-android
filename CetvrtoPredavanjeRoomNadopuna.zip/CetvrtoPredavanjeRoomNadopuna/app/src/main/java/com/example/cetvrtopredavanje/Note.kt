package com.example.cetvrtopredavanje

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.Entity

@Entity
class Note (

    @PrimaryKey(autoGenerate = true) var uid:Int,
    @ColumnInfo(name = "noteTitle") var noteTitle: String?,
    @ColumnInfo(name = "noteDate") var noteDate: String?,
    @ColumnInfo(name = "noteDescription") var noteDescription: String?



)