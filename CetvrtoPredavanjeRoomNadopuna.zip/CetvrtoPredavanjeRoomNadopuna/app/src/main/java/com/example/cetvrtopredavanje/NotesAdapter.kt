package com.example.cetvrtopredavanje

import android.app.Activity
import android.arch.persistence.room.Room
import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*


class NotesAdapter: RecyclerView.Adapter<NotesAdapter.ViewHolder> (){

    var EDIT: Int = 2

    class ViewHolder(itemView: View, context2: Context):RecyclerView.ViewHolder(itemView){
        var noteTitleTextView: TextView? = null
        var noteDate: TextView? = null
        var deleteButton: ImageButton? = null
        var noteRow: RelativeLayout? = null
        var context: Context? = null
        var db: NotesDatabase? = null


        init{
            noteTitleTextView = itemView.findViewById(R.id.textView)
            noteDate = itemView.findViewById(R.id.noteDate)
            deleteButton = itemView.findViewById(R.id.delete_button)
            noteRow = itemView.findViewById(R.id.noteTitleTextView)
            context = context2
            db = Room.databaseBuilder(
                context2.applicationContext,
                NotesDatabase::class.java,"note_database"
            ).build()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        val notesListElement = inflater.inflate(R.layout.note_title, parent, false)
        return ViewHolder(notesListElement,context)
    }

    override fun getItemCount(): Int {
        return NotesList.notesList.size
    }

    override fun onBindViewHolder(parent: ViewHolder, p1: Int) {
        parent.noteTitleTextView?.text = NotesList.notesList[p1].noteTitle
        val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
        val currentDate = sdf.format(Date())
        parent.noteDate?.text = currentDate
        parent.deleteButton?.setOnClickListener {
            System.out.println(p1)
            Thread(Runnable {
                println(p1)
                parent.db?.noteDao()?.deleteNote(NotesList.notesList.get(p1).uid)
                NotesList.notesList.removeAt(p1)
                (parent.context as MainActivity).runOnUiThread {
                    notifyDataSetChanged()
                }
            }).start()

        }
        parent.noteRow?.setOnClickListener {
            var intent: Intent = Intent(parent.context, NoteDetailsActivity::class.java)
            intent.putExtra("new", 0)
            intent.putExtra("position", p1)
            (parent.context as Activity).startActivityForResult(intent, EDIT)
            notifyDataSetChanged()

        }
    }
}