package com.example.cetvrtopredavanje

object NotesList {

    var notesList: MutableList<Note> = mutableListOf()

}